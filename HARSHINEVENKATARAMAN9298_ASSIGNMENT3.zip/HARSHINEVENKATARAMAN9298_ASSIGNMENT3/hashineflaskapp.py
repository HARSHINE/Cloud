from flask import Flask,render_template, request, redirect
import pymysql,csv,time,random,hashlib
import memcache
app = Flask(__name__)

# credentials to connect database

hostname = 'harshinedb.mysql.database.azure.com'
username = 'harshine@harshinedb'
password = 'RadheKrishna1'
database = 'cloud'
myConnection = pymysql.connect(host=hostname, user=username, passwd=password, db=database, autocommit=True,cursorclass=pymysql.cursors.DictCursor, local_infile=True)
	# print "Database Connected"
application = Flask(__name__)
app = application

def memcache_connect():
    #Connecting to the memcache
	memc = memcache.Client(['23.99.134.88'], debug = 1)
	print "Memcache connected"
	return memc

UPLOAD_FOLDER = '/home/harshine/flaskapp/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
					   
							   
@app.route("/")
def hello():#For displaying the first page
    return render_template("index.html")

@app.route("/uploadcsvfile", methods = ['POST'])
def uploadcsvfile():#For uploading the file
	file = request.form['csvfile']	
        #Conn=myConnection.cursor()
	#filename=file
	#filename=UPLOAD_FOLDER+filename
	# dropquery="drop table IF EXISTS "+ filename[:-4]
	# with Conn.cursor() as curs:
		# curs.execute(dropquery)
		# Conn.commit()
	# print "dropped"
	# columnname="("
	absfilename=UPLOAD_FOLDER+file
	# with open(abs_filename, 'r') as f:
		# reader = csv.reader(f)
		# for row in reader:
			# line=row
			# break
	# for i in line:
		# columnname+=i+" VARCHAR(50),"
	# query="Create table if not exists " + filename[:-4]+columnname+" sr_no INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(sr_no));"
	# print query
	# with Conn.cursor() as curs:
		# curs.execute(query)
		# Conn.commit()
	# curs.close()
	# print "successfully created"
	
	insert_data="""LOAD DATA LOCAL INFILE '"""+absfilename+ """'INTO TABLE equake FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;"""
	print (insert_data)
	with myConnection.cursor() as curs:
		curs.execute(insert_data)
		myConnection.commit()
	print "successfully loaded"
	return render_template("index.html",message="file uploaded")

@app.route('/memexecute', methods=['POST'])
def memexecute():#For implementing memcache
	mc = memcache_connect()
	#mc.flush_all()
	limit = request.form['limit']
	print limit
	locquery="select * from equake"
	print (locquery)
	new_key = locquery.replace(' ','')
    	value = mc.get(new_key) #value = mc.get("key")
	print value
	starttime = time.time()
    	print(starttime)
    	if value is None:
		print "entered memcache"
		with myConnection.cursor() as cursor:
        		cursor.execute(locquery)
		        rows=cursor.fetchall()
			result=" "
			for i in rows:
				result+=str(i)
			cursor.close()
			print "fetched"
			print (result)
			status = mc.set(new_key,result) 
			print (status)
			print (mc.get(new_key))			
	else:
		print (mc.get(new_key))        
    	endtime = time.time()
    	print('endtime')
    	totalsqltime = endtime - starttime
    	print(totalsqltime)
		#specific query
        
	#specific query
	longitude1= request.form['long1']
	latitude1 = request.form['lat1']
	query="select * from equake where longitude=%s and latitude=%s"
	print (query)
	new_key =query.replace(' ','')
    	value = mc.get(new_key) #value = mc.get("key")
	print value
	starttime = time.time()
    	print(starttime)
    	if value is None:
		print "entered memcache"
	        curs=myConnection.cursor()
                curs.execute(query,(longitude1,latitude1,))
     	        result=curs.fetchall()
		status = mc.set(new_key,result) 
		print (status)
		print (mc.get(new_key))			
	else:
		print (mc.get(new_key))        
    	endtime = time.time()
    	print('endtime')
    	totalsqltime1 = endtime - starttime
    	print(totalsqltime1)
    	return render_template('filehandle.html', rdstime4=totalsqltime, rdstime5=totalsqltime1)


  
if __name__ == '__main__':
  app.run()