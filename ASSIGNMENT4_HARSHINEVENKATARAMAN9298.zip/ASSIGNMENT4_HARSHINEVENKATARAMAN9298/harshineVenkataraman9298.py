from flask import Flask,render_template,request
import csv,base64,time


import matplotlib
matplotlib.use('Agg')
 
 
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import numpy as np

app = Flask(__name__)



@app.route('/')
def index():
  return render_template('index.html')
  
  # credentials to connect database

hostname = 'harshinedb.mysql.database.azure.com'
username = 'harshine@harshinedb'
password = 'RadheKrishna1'
database = 'cloud'
myConnection = pymysql.connect(host=hostname, user=username, passwd=password, db=database, autocommit=True,cursorclass=pymysql.cursors.DictCursor, local_infile=True)
	# print "Database Connected"
application = Flask(__name__)
app = application

def memcache_connect():
    #Connecting to the memcache
	memc = memcache.Client(['23.99.134.88'], debug = 1)
	print "Memcache connected"
	return memc

UPLOAD_FOLDER = '/home/harshine/flaskapp/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
					   
							   
@app.route("/")
def hello():#For displaying the first page
    return render_template("index.html")

@app.route("/uploadcsvfile", methods = ['POST'])
def uploadcsvfile():#For uploading the file
	file = request.form['csvfile']	
        #Conn=myConnection.cursor()
	#filename=file
	#filename=UPLOAD_FOLDER+filename
	# dropquery="drop table IF EXISTS "+ filename[:-4]
	# with Conn.cursor() as curs:
		# curs.execute(dropquery)
		# Conn.commit()
	# print "dropped"
	# columnname="("
	absfilename=UPLOAD_FOLDER+file
	# with open(abs_filename, 'r') as f:
		# reader = csv.reader(f)
		# for row in reader:
			# line=row
			# break
	# for i in line:
		# columnname+=i+" VARCHAR(50),"
	# query="Create table if not exists " + filename[:-4]+columnname+" sr_no INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(sr_no));"
	# print query
	# with Conn.cursor() as curs:
		# curs.execute(query)
		# Conn.commit()
	# curs.close()
	# print "successfully created"
	
	insert_data="""LOAD DATA LOCAL INFILE '"""+absfilename+ """'INTO TABLE titanic3 FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;"""
	print (insert_data)
	with myConnection.cursor() as curs:
		curs.execute(insert_data)
		myConnection.commit()
	print "successfully loaded"
	return render_template("index.html",message="file uploaded")


mylist = []
@app.route('/ClusterDistance', methods=['GET', 'POST'])
def ClusterDistance():
        attribute1 = request.form['attribute1']
        attribute2 = request.form['attribute2']
         
		 
		 clusters = request.form['clusters']
        Kcluster = int(clusters)
        
		
		mylist = getdata(attribute1,attribute2)
        data = []
        
		
		
		Cdistance=[]
        data = array(mylist)
        cent, pts = kmeans2(data,Kcluster)
        ClusterDistance = []
        for i in range(len(cent)):
            x1 = cent[i][0]
            y1 = cent[i][1]
            x1 = float("{0:.3f}".format(x1))
            y1 = float("{0:.3f}".format(y1))

            for j in range(i+1,len(cent)):
                dc = {}
                x2 = cent[j][0]
                y2 = cent[j][1]
                x2 = float("{0:.3f}".format(x2))
                y2 = float("{0:.3f}".format(y2))
                dist = np.sqrt((x1-x2)*2 + (y1-y2)*2)
                Cdistance.append(dist)
                dc['dist'] = "Distance between cluster " + str(i) + " and cluster " + str(j) + " is: " + str(dist)
                ClusterDistance.append(dc)
                print (ClusterDistance)
                print ("Distance between cluster " + str(i) + " and cluster " + str(j) + " is: " + str(dist))
        

        
		
		
		  f_write='Cluster,Count\r\n'
        cnt=0
        print (clr_dict)
        for i in clr_dict:
            if clr_dict[i] == 0:
                continue
            string = str(cnt) + " : " + str(clr_dict[i])
            picdistance.append(string)
            print ("No of points in cluster with " + str(i) + " is: " + str(clr_dict[i]))
            f_write+= str(cnt)+','+str(clr_dict[i])+'\r\n'
            cnt += 1
        with open("home/harshine/flaskapp/titanic3.csv",'wb') as nfile:
            nfile.write(f_write.encode("utf-8"))
        pylab.scatter(data[:,0],data[:,1], c=colors)
        pylab.scatter(cent[:,0],cent[:,1], marker='o', s = 400, linewidths=3, c='none')
        pylab.scatter(cent[:,0],cent[:,1], marker='x', s = 400, linewidths=3)

        pylab.savefig("home/harshine/flaskapp/visualization.png")

        return render_template('index.html',Cdistance=Cdistance, ClusterDistance = ClusterDistance)